﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using spawn.cs;
public class vivant : MonoBehaviour
{
    Gameobjet Cellule1;
    Gameobjet Cellule2;
    Gameobjet Cellule3;

    bool vivant;
    var Position12 = Cellule1.position - Cellule2.position;
    var Position13 = Cellule1.position - Cellule3.position;

    var Position23 = Cellule2.position - Cellule3.position;




    void Start()
    {
        if (Position12 >= 1)
        {

        }
        if (Position13 >= 1)
        {

        }
        if (Position23 >= 1)
        {

        }
    }

    void Update()
    {


    }
}
