﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class spawn : MonoBehaviour
{
    public GameObject Cellule;
    public float PlaceX;
    public float PlaceZ;

    void Start()
    {
        PlaceX = Random.Range(0, 5);
        PlaceZ = Random.Range(0, 5);


        Cellule.transform.position = new Vector3(PlaceX, 1, PlaceZ);
    }
}